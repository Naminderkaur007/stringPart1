



import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        differentWayToIntializeString()
    }
    
   
    func differentWayToIntializeString(){
        
         
         let empty = ""  //no memory
         let alsoEmpty = String()//no memory
      //You can provide a type annotation when you declare a constant or variable, to be clear
      //about the kind of values the constant or variable can store
         let dValue : String //no memory
         var gValue : String?  //no memory (optional Varaible)
      
      
         let aValue =  "Hello" //have memory
         let bValue = String("V") //have memory
         let cValue = String("World") //have memory
         let eValue : String = "Reality"  //have memory
         var fValue : String!  //have memory (force unWrapping Sign(!)
         
         print("Empty = \(empty)")
         print("AlsoEmpty = \(alsoEmpty)")
         print("aValue = \(aValue)")
         print("bValue = \(bValue)")
         print("cValue = \(cValue)")
         dValue = "Virtual"
         print("cValue = \(dValue)")
         print("eValue = \(eValue)")
        
         fValue = nil
         gValue = nil
         print("fValue = \(fValue ?? "defaultValue")")
         print("fValue = \(fValue)")
         fValue = "do well"
         print(fValue)
         fValue = nil
         print(fValue)
        // fValue = defaultValue
        // fValue = nil
        // Optional("do well")
        // nil
         
         
       print("gValue = \(gValue)")
       gValue = "do well"
       print(gValue)
       print(gValue!)
       gValue = nil
       print(gValue)
          //gValue = nil
         //Optional("do well")
        //do well
       //nil
         
     }


}


